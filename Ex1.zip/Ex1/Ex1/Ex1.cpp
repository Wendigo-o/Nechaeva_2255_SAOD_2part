﻿using namespace std;

#include <iostream>

int main()
{
    cout << "Hello World!\n";
}
