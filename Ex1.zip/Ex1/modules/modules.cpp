﻿using namespace std;
#include <iostream>
#include "utils.h"


int main()
{
    int x = 3, y = 5;
    cout << x + y << endl;
    cout << Plus(x, y) << endl;
}
